#!/bin/bash

echo "🔧 Vite 프로젝트 빌드 중..."
npm run build

echo "🚀 GitHub Pages에 배포 중..."
npm run deploy

echo "✅ 완료! https://themists.github.io/dictionary 에서 확인해보세요."
